# Peak archive — ClosableNsRockInn

- Kaggle: [`55517032`](https://www.kaggle.com/competitions/pokemon-tcg-ai-battle/submissions) publicScore **549.8** (fade snapshot also noted ~559)
- Stack: LeakFix Dry861 + **Closable861** + **NsWater861** + **RockInn** (Jetting bench-50 always legal through Rock Inn)
- Deck: 2× Staryu / 4× Risky Ruins / Water×5 + Dark×3 (**no Ignition**)
- Local fade: `data/kaggle_episodes/review_ClosableNsRockInn_55517032/`
- Frozen: 2026-08-16

## Restore

```bash
cp -a data/restore_peaks/closableNsRockInn_55517032/{deck.csv,main.py,weights.json,cg,pilot} submission_starmie/
python3 scripts/package_starmie.py   # or tar the submission_starmie dir
```

Do **not** overlay IgnitionNebula / LilliePreserve / EmptyBench on this peak without a new gate.
